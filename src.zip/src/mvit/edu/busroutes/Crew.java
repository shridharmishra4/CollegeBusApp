
package mvit.edu.busroutes;

public class Crew {

	long BusNo;
	String DriverName;
	String DriverPhno;

	public long getBusNo() {
		return BusNo;
	}

	public void setBusNo(long busNo) {
		BusNo = busNo;
	}

	public String getDriverName() {
		return DriverName;
	}

	public void setDriverName(String driverName) {
		DriverName = driverName;
	}

	public String getDriverPhno() {
		return DriverPhno;
	}

	public void setDriverPhno(String driverPhno) {
		DriverPhno = driverPhno;
	}

}
